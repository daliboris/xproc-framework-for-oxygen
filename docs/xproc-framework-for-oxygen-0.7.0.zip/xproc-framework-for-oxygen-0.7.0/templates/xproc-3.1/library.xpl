<p:library  xmlns:p="http://www.w3.org/ns/xproc" 
 xmlns:xs="http://www.w3.org/2001/XMLSchema" 
 xmlns:xf="https://www.example.com/ns/xproc/function"
 xmlns:xhtml="http://www.w3.org/1999/xhtml"
 version="3.0">
 
 <p:documentation>
  <xhtml:section>
   <xhtml:h1></xhtml:h1>
   <xhtml:p></xhtml:p>
  </xhtml:section>
 </p:documentation>
 
 <!-- 
      ×××××××××××××××××××××××××××
      ×××××  PIPELINE STEP  ×××××
      ×××××××××××××××××××××××××××
 -->
 <p:declare-step type="xf:first-function" name="fist-function">
  <p:documentation>
   <xhtml:section>
    <xhtml:h2></xhtml:h2>
    <xhtml:p></xhtml:p>
   </xhtml:section>
  </p:documentation>
  
  <!--
   >>>>>>>>>>>>>>>>>
   >> INPUT PORTS >>
   >>>>>>>>>>>>>>>>>
  -->
  <p:input  port="source" primary="true" />
  
  <!--
   <<<<<<<<<<<<<<<<<<
   << OUTPUT PORTS <<
   <<<<<<<<<<<<<<<<<<
  -->
  <p:output port="result" primary="true" />
  
  <!--
   +++++++++++++
   ++ OPTIONS ++
   +++++++++++++
  -->
  <p:option name="debug-path" as="xs:anyURI?" select="()" />
  <p:option name="base-uri" as="xs:anyURI" select="static-base-uri()" />
  
  <!--
   ÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷
   ÷÷ VARIABLES ÷÷
   ÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷
  -->
  <p:variable name="debug" as="xs:boolean" select="$debug-path || '' ne ''" />
  <p:variable name="debug-path-uri" as="xs:anyURI?" select="if(empty($debug-path)) 
   then () 
   else p:urify($debug-path, $base-uri)" />
  
  
  <!--
   *******************
   ** PIPELINE BODY **
   *******************
  -->
  <p:xslt>
   <p:with-input port="stylesheet" href="../xslt/?.xsl" />
   <p:with-option name="parameters" select="map {'parameter' : 'value' }" />
  </p:xslt>
  
  <p:if test="$debug">
   <p:store href="{$debug-path-uri}/?.?" />
  </p:if>
 
 </p:declare-step>
 
</p:library>